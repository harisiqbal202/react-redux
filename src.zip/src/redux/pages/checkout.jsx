import React from "react";

function CheckOut() {
  return <></>;
}

export default CheckOut;
